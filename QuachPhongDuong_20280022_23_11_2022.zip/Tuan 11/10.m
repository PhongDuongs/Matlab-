clc
clear all
close all
syms x
L1=int(exp(x),0,pi)
L2=int((sin(x)/x),0,1)
L3=int(2^x,0,2)
L4=int(1/(x^2+2),0,1)