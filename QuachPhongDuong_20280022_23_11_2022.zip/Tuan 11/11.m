clc
clear all
close all
syms x
f=x
double(int(f,0,1))
I=double(Xapxi_tichphan(f,0,1,2))
I=double(Xapxi_tichphan(f,0,1,4))
I=double(Xapxi_tichphan(f,0,1,10))
I=double(Xapxi_tichphan(f,0,1,20))