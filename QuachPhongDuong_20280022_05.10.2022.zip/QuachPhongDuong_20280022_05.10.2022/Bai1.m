clc
clear all
close all
A = [2 4 1; 6 7 2; 3 5 9]
x=A(1,:)
y=A(2:3,:)
S_r=sum(A,2)
S_c=sum(A,1)
max(max(A))
min(min(A))
sum(sum(A))
