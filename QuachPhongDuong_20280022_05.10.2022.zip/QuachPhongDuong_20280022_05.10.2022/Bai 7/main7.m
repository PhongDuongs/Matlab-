A=[2 1 2;3 1 3]
n=input('Nhap n: ');
S=HamTinh_Tong_Matran(A,n)