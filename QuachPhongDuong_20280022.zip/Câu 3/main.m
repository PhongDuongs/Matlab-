clc
clear all
close all
sum=0;
for i=1:10
    sum=sum+fib(i);
end
fprintf('Tong 10 so Fibonacci dau tien la: %d\n',sum);

for i=1:1000
    if( and(fib(i)<1000,fib(i+1)>=1000))
        fprintf('N duoc tim thay la : %d\n',i);
    end
end

sum=0;
for i=1:50
    if( or(mod(fib(i),2)==0,mod(fib(i),5)==0))
        sum=sum+fib(i);
    end
end
fprintf('Tong so fibonacci chia het cho 2 va 5 la: %d\n',sum);
        


        