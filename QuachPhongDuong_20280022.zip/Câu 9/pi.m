PI=0;
for i=0:10000
    if abs(pi-PI) < 10^-9
        break;
    end
    PI = PI + 4*(-1)^i/(2 * i + 1);
end
disp(i)
