function [FOR_A,WHILE_A]=A7()
f=0;
x=[];
j=1;
k=1;
fw=0;
    for i=1:10000
       temp= 5/(i*(i+1)) ;
       f=f+temp;
       if( and(f>3,f<=4))
           x(j)=i;
           j=j+1;
       end
    end
    FOR_A=max(x);
    while 1
        fw = fw + (5/(k*(k+1)));
        if fw >= 4
            break;
        end
        k = k+1;
    end
    WHILE_A=k;
end
