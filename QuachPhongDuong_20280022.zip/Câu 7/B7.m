function [FOR_B,WHILE_B]=B7()
f=0;
x=[];
j=1;
k=1;
fw=0;
    for i=1:10000
       temp= 1/(i*(i+3)) ;
       f=f+temp;
       if( and(f>=1/2,f<1))
           x(j)=i;
           j=j+1;
       end
    end
    FOR_B=min(x);
    while 1
        fw = fw + (1/(k*(k+3)));
        if fw >= 1/2
            break;
        end
        k = k+1;
    end
    WHILE_B=k;
end