clc 
clear all
[FOR_A,WHILE_A]=A7()
[FOR_B,WHILE_B]=B7()
[FOR_C,WHILE_C]=C7()
