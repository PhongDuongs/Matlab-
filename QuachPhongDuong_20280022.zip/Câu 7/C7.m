function [FOR_C,WHILE_C]=C7()
f=0;
x=[];
k=1;
fw=0;
j=1;
    for i=1:10000
       temp= i^2/(i^2+1) ;
       f=f+temp;
       if( and(f>=10,f<11))
           x(j)=i;
           j=j+1;
       end
    end
    FOR_C=min(x);
    while 1
        fw = fw + (k^2/(k^2+1));
        if fw >= 10
            break;
        end
        k = k+1;
    end
    WHILE_C=k;
end