function [FOR,WHILE] = sinx(x)
sin2=0;
sin1=0;
j=0;
for i=0:inf
    if abs(sin(x) - sin1) <= 1E-6 %V�ng for th� ss voi 1E-6
        break;
    end
    sin1 = sin1 + (-1)^i*x^(2*i+1)/factorial(2*i+1);
end
FOR=i;
while 1
    if abs(sin(x) - sin2) <= 1E-12 %V�ng while th� ss voi 1E-12
        break;
    end
    sin2 = sin2 + (-1)^j*x^(2*j+1)/factorial(2*j+1);
    j = j+1;
end
WHILE=j;
end