clc
% Cho v� d? voi x=2;
[FOR,WHILE] = ex(2)
[FOR,WHILE] = sinx(2)
[FOR,WHILE] = cosx(2)