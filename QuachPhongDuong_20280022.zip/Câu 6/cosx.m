function [FOR,WHILE] = cosx(x)
COS=0;
COS2=0;
j=0;
for i=0:inf
    if abs(cos(x) - COS) <= 10^-6 %V�ng for th� ss voi 1E-6
        break;
    end
    COS = COS + (-1)^i*x^(2*i)/factorial(2*i);
end
FOR=i;
while 1
    if abs(cos(x) - COS2) <= 10^-12 %V�ng while th� ss voi 1E-12
        break;
    end
    COS2 = COS2 + (-1)^j*x^(2*j)/factorial(2*j);
    j = j+1;
end
WHILE=j;
end