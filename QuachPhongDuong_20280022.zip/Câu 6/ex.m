function [FOR,WHILE] = ex(x)
ex=0;
ex2=0;
j=0;
for i=0:inf
    if abs(exp(x) - ex) <= 1E-6 %V�ng for th� ss voi 1E-6
        break;
    end
    ex = ex + x^i/factorial(i);
end
FOR=i;
while 1
     if abs(exp(x) - ex2) <= 1E-12 %V�ng while th� ss voi 1E-12
        break;
    end
    ex2 = ex2 + x^j/factorial(j);
    j = j+1;
end
WHILE=j;
end