clc
clear all
close all
A = [5 2 1; 8 7 3; 9 8 6]
[m,n]=size(A);
x=zeros(1,m);
k=1;
for i=1:m
    for j=1:n
        x(k)=A(i,j);
        k=k+1;
    end
end
bar(x)
xlabel('Cac phan tu cua ma tran')
ylabel('Diem')
title('Do thi cot ve ma tran')
        
