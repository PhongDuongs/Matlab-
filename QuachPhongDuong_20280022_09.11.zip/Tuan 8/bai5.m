t=0:pi/100:6*pi;
x=sin(t);
y=cos(t);
z=t;
plot3(x,y,z)
xlabel('x');
ylabel('y');
zlabel('z');
title('Do thi ham so cua x,y va z')