tong = 850+720+320;
coca=850/tong;
pesi=720/tong;
conlai=320/tong;
pie([coca,pesi,conlai])
labels = {'Coca','Pesi','Con lai'};
legend(labels,'Location','southoutside','Orientation','horizontal')