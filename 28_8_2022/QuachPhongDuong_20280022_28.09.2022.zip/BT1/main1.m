n=input('Nhap n: ');
k=input('Nhap k: ');
C=combi(n,k);
fprintf('Ket qua: %d',C);

