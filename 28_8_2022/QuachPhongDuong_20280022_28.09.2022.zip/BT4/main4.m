clear all
close all
a=input('Nhap a: ');
square(a);