clc
clear all
close all

n=input('Nhap n: ');
CV3(n);