clc
clear all
close all
syms x
int(sqrt(1-x^2))
int(sin(sqrt(x)))
int(cos(x)^4,0,pi/2)
int(abs(x-5),0,10)
int(tan(x),pi/4,pi/3)